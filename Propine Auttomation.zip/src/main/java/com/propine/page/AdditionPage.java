package com.propine.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AdditionPage {
	WebDriver driver;

	@FindBy(name = "firstNumber")
	WebElement firtstNumber;
	@FindBy(name = "secondNumber")
	WebElement secondNumber;
	@FindBy(xpath = "//input[@type='submit']")
	WebElement submitButton;
	@FindBy(css = "div.col-md-6>div")
	WebElement result;

	public AdditionPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void enterfirstNumber(String strUserNfirstNumber) {
		
		this.firtstNumber.sendKeys(strUserNfirstNumber);
	}

	public void enterSecondNumber(String strSecondNumber) {
		this.secondNumber.sendKeys(strSecondNumber);
	}

	public void clickSubmit() {
		this.submitButton.click();
	}

	public String getResults() {
		return this.result.getText().trim();

	}

	public boolean isValueEntered(WebElement ele, String txt) {
		return ele.getAttribute("value").equals(txt);
	}

}
