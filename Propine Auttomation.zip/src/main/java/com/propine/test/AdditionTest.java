package com.propine.test;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.propine.page.AdditionPage;

public class AdditionTest {
	WebDriver driver;
	AdditionPage additionPage;

	@BeforeTest
	public void browserLaunch() {
		System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe");
		this.driver = new ChromeDriver();
		driver.get("https://vast-dawn-73245.herokuapp.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

	}

	@Test(dataProvider = "data-provider")
	public void addtionTwo_Number(String f, String s, String r) {
		nap(500);
		this.additionPage = new AdditionPage(driver);
		additionPage.enterfirstNumber(f);
		additionPage.enterSecondNumber(s);
		additionPage.clickSubmit();
		assertEquals(additionPage.getResults(), r);
	}

	@DataProvider(name = "data-provider")
	public Object[][] additionDataProvider() {
		return new Object[][] { { "7", "5", "12" }, { "-9", "7", "-2" },{"17","-9","8"}
		,{"-9","-8","-17" },{"0","1","1"},{"0","0","0"},
			{"9.0","8.0","17"},{"9.00","7.00","16"},{"0.9","0.1","1"},{"-0.9","-0.7","-1.6"},{"0.9","-0.1","0.8"},
			{"a9","b5","NaN"},{"9a","7b","NaN"},{"a","b","NaN"}
		};
	}

	@AfterTest
	public void closeBrowser() {
		driver.close();
	}
	
	public void nap(int milisec) {
		try {
			Thread.sleep(milisec);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}